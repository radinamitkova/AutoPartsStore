create FUNCTION sumColumn
(prm1 DATE, prm2 IN DATE)
RETURN NUMBER AS
sum_var NUMBER := 0;
BEGIN
SELECT SUM(atr1)INTO sum_var FROM tab1
WHERE atr2 BETWEEN prm1 AND prm2;
RETURN sum_var;
END;
/

