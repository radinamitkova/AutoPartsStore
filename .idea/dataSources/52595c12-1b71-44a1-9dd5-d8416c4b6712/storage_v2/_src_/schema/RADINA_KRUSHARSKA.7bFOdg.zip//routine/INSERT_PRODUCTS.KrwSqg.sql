create PROCEDURE insert_products (name IN varchar,
name_product IN varchar, unit_grams IN number, calories IN number, 
unit_price IN number)
AS
BEGIN
INSERT INTO products(name, type, unit_grams, calories, unit_price)
VALUES(name,
(SELECT ID FROM Product_types
WHERE name = name_product),
unit_grams, calories, unit_price);
END;
/

